module.exports = function(grunt) {
  return {
    install: {
      // defaults are fine
    }
  };
};